---
name: llm-gateway
description: Local LLM gateway that adds free OpenRouter models to the Claude Code /model picker
metadata: 
  node_type: memory
  type: project
  originSessionId: afa3ddee-0fad-4ea7-82a9-e9af8ead6f71
---

User runs a local gateway at `~/llm-gateway` (Docker Compose) so the Claude Code `/model`
picker shows free OpenRouter models alongside Opus/Sonnet/Haiku.

Architecture: a small Python `router` (127.0.0.1:4000) serves `GET /v1/models` (static
Anthropic-format list of `claude-free-*` ids) and routes `POST /v1/messages` by model —
`claude-free-*` → LiteLLM → OpenRouter; everything else → RAW passthrough to
api.anthropic.com (so Anthropic prompt caching / tool use / betas stay intact). The real
ANTHROPIC_API_KEY lives only server-side in `~/llm-gateway/.env` (also OPENROUTER_API_KEY).

Claude Code wiring is in `~/.bashrc`: `ANTHROPIC_BASE_URL=http://127.0.0.1:4000` and
`CLAUDE_CODE_ENABLE_GATEWAY_MODEL_DISCOVERY=1`, plus a `claude-direct` shell function to
bypass the gateway. Do NOT set `ANTHROPIC_AUTH_TOKEN` — it conflicts with the managed
`/login` API key (Claude Code warns "Auth conflict"). The router strips/ignores client
auth entirely and uses the keys baked into `.env`, so the managed login key is enough.

Key facts: discovery needs ids starting with `claude`; built-in models always remain.
DeepSeek V3/R1 are NO LONGER on OpenRouter's free tier (as of 2026-06) — current free
picks: qwen3-coder, llama-3.3-70b, kimi-k2.6, gpt-oss-120b, glm-4.5-air, qwen3-next-80b.
User account is API-key billing (subscriptionType None), aarch64 Raspberry Pi.
Docker needs `sudo` until next login (user was added to `docker` group). See README.md there.
