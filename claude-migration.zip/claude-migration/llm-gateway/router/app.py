"""Tiny routing proxy in front of LiteLLM.

- GET  /v1/models   -> static Anthropic-format list of the free models, so Claude
                       Code gateway discovery can populate the /model picker.
- POST /v1/messages -> if model id starts with "claude-free-", forward to LiteLLM
                       (which translates Anthropic <-> OpenRouter). Otherwise do a
                       RAW pass-through to api.anthropic.com using the real key, so
                       native Anthropic features (prompt caching, tool use, betas,
                       streaming) are preserved bit-for-bit.
"""
import os
import json
import logging

from aiohttp import web, ClientSession, ClientTimeout

logging.basicConfig(level=logging.INFO, format="%(asctime)s router %(message)s")
log = logging.getLogger("router")

ANTHROPIC_BASE = "https://api.anthropic.com"
LITELLM_BASE = os.environ.get("LITELLM_BASE", "http://litellm:4000")
ANTHROPIC_API_KEY = os.environ["ANTHROPIC_API_KEY"]
LITELLM_KEY = os.environ.get("LITELLM_MASTER_KEY", "sk-gateway-local")

# (model id exposed to Claude Code, human display name). The id MUST start with
# "claude" or Claude Code will filter it out of the picker.
FREE_MODELS = [
    ("claude-free-qwen3-coder", "Qwen3 Coder (free)"),
    ("claude-free-llama-3.3-70b", "Llama 3.3 70B (free)"),
    ("claude-free-kimi-k2.6", "Kimi K2.6 (free)"),
    ("claude-free-gpt-oss-120b", "GPT-OSS 120B (free)"),
    ("claude-free-glm-4.5-air", "GLM 4.5 Air (free)"),
    ("claude-free-qwen3-next-80b", "Qwen3-Next 80B (free)"),
]

# headers we must not copy verbatim between client/upstream. content-encoding is
# dropped from the *response* because the router decompresses upstream bodies
# (auto_decompress=True) and serves plaintext — critical for clean SSE streaming.
HOP = {
    "host", "content-length", "connection", "keep-alive",
    "transfer-encoding", "x-api-key", "authorization", "accept-encoding",
    "content-encoding",
}


async def handle_models(request):
    data = [
        {"type": "model", "id": mid, "display_name": name,
         "created_at": "2026-01-01T00:00:00Z"}
        for mid, name in FREE_MODELS
    ]
    return web.json_response({
        "data": data,
        "has_more": False,
        "first_id": data[0]["id"] if data else None,
        "last_id": data[-1]["id"] if data else None,
    })


async def handle_proxy(request):
    body = await request.read()
    model = ""
    if body:
        try:
            model = json.loads(body).get("model", "") or ""
        except Exception:
            pass

    free = model.startswith("claude-free-")
    if free:
        base, auth = LITELLM_BASE, {"Authorization": f"Bearer {LITELLM_KEY}"}
    else:
        base, auth = ANTHROPIC_BASE, {"x-api-key": ANTHROPIC_API_KEY}

    headers = {k: v for k, v in request.headers.items() if k.lower() not in HOP}
    headers.update(auth)

    url = base + request.rel_url.raw_path
    if request.rel_url.raw_query_string:
        url += "?" + request.rel_url.raw_query_string

    log.info("%s %s -> %s (model=%s)", request.method, request.rel_url.raw_path,
             "litellm" if free else "anthropic", model or "-")

    session = request.app["session"]
    timeout = ClientTimeout(total=None, sock_connect=30, sock_read=None)
    up = await session.request(request.method, url, data=body,
                               headers=headers, timeout=timeout)

    resp = web.StreamResponse(
        status=up.status,
        headers={k: v for k, v in up.headers.items() if k.lower() not in HOP},
    )
    await resp.prepare(request)
    try:
        async for chunk in up.content.iter_any():
            await resp.write(chunk)
    finally:
        up.release()
    await resp.write_eof()
    return resp


async def on_start(app):
    # decompress upstream so we forward plaintext (clean incremental SSE);
    # content-encoding is stripped from the response in HOP accordingly.
    app["session"] = ClientSession(auto_decompress=True)


async def on_clean(app):
    await app["session"].close()


def make_app():
    app = web.Application(client_max_size=1024 ** 3)
    app.router.add_get("/healthz", lambda r: web.json_response({"ok": True}))
    app.router.add_get("/v1/models", handle_models)
    app.router.add_route("*", "/{tail:.*}", handle_proxy)
    app.on_startup.append(on_start)
    app.on_cleanup.append(on_clean)
    return app


if __name__ == "__main__":
    web.run_app(make_app(), host="0.0.0.0", port=4000)
