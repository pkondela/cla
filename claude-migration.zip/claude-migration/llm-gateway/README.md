# Claude Code local LLM gateway

Adds free OpenRouter models to the Claude Code `/model` picker while keeping
Opus/Sonnet/Haiku working natively.

## Architecture
    Claude Code  ->  router (127.0.0.1:4000)
        GET /v1/models      -> static Anthropic-format list of free models
        POST /v1/messages    model "claude-free-*" -> LiteLLM -> OpenRouter
                             otherwise (Opus/Sonnet/Haiku) -> RAW passthrough to api.anthropic.com
    LiteLLM (internal :4000) -> OpenRouter

Anthropic traffic is byte-for-byte passthrough (prompt caching / tool use / betas intact).

## Files
- docker-compose.yml      two services: router (built) + litellm
- router/app.py           the routing proxy
- litellm-config.yaml      free model -> OpenRouter slug mapping
- .env                     ANTHROPIC_API_KEY, OPENROUTER_API_KEY, LITELLM_MASTER_KEY, GATEWAY_TOKEN (chmod 600)

## Claude Code wiring (in ~/.bashrc)
    ANTHROPIC_BASE_URL=http://127.0.0.1:4000
    ANTHROPIC_AUTH_TOKEN=<GATEWAY_TOKEN>      # router ignores it; real key lives server-side
    CLAUDE_CODE_ENABLE_GATEWAY_MODEL_DISCOVERY=1
    claude-direct   # shell function: run Claude Code bypassing the gateway

## Manage
    cd ~/llm-gateway
    docker compose ps
    docker compose logs -f router      # see routing decisions (anthropic vs litellm)
    docker compose restart
    docker compose down                # stop (also disables Anthropic until back up!)
    docker compose up -d --build       # start / rebuild

## Add / change free models
Edit litellm-config.yaml (model_name must start with "claude-") AND the FREE_MODELS
list in router/app.py, then: docker compose up -d --build
