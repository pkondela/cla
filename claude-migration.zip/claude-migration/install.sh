/usr/bin/env bash
set -euo pipefail

# Claude Code + LLM Gateway Kompletná Inštalácia

echo "========================================"
echo "Claude Code + LLM Gateway Installer"
echo "========================================"
echo ""

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Kontrol Dockeru
if ! command -v docker &> /dev/null; then
    echo "❌ Docker nie je nainštalovaný. Prosím nainštalujte Docker."
    exit 1
fi

if ! command -v docker-compose &> /dev/null; then
    echo "❌ Docker Compose nie je nainštalovaný. Prosím nainštalujte Docker Compose."
    exit 1
fi

# Kontrola .env
if [ ! -f "$SCRIPT_DIR/llm-gateway/.env" ]; then
    if [ -f "$SCRIPT_DIR/llm-gateway/.env.template" ]; then
        echo "⚠️  .env súbor neexistuje. Kopírujem z .env.template..."
        cp "$SCRIPT_DIR/llm-gateway/.env.template" "$SCRIPT_DIR/llm-gateway/.env"
        echo "❌ Doplňte API kľúče do $SCRIPT_DIR/llm-gateway/.env a spustite skript znova."
        exit 1
    fi
fi

echo "🚀 Spúšťam LLM Gateway..."
cd "$SCRIPT_DIR/llm-gateway"
docker compose up -d --build

echo "⏳ Čakám na štart služieb (30 sekúnd)..."
sleep 5

# Healtcheck
if docker ps | grep -q llm-gateway; then
    echo "✅ LLM Gateway beží úspešne."
else
    echo "❌ LLM Gateway nebeží. Skontrolujte logy: cd llm-gateway && docker compose logs"
    exit 1
fi

echo "📋 Nastavujem Claude Code konfiguráciu..."
mkdir -p "$HOME/.claude"

# Kopírovanie konfigurácie (len súbory, nie celé priečinky, aby sa neprepsala aktuálna história)
if [ -f "$SCRIPT_DIR/claude-config/settings.json" ]; then
    cp "$SCRIPT_DIR/claude-config/settings.json" "$HOME/.claude/settings.json"
    echo "✅ settings.json bola nastavená."
fi

# Projekt memory
if [ -d "$SCRIPT_DIR/claude-config/projects" ]; then
    mkdir -p "$HOME/.claude/projects"
    cp -r "$SCRIPT_DIR/claude-config/projects/"* "$HOME/.claude/projects/" 2>/dev/null || true
    echo "✅ Projektové dáta boli skopírované."
fi

# História (voliteľné)
if [ -f "$SCRIPT_DIR/claude-config/history.jsonl" ] && [ ! -f "$HOME/.claude/history.jsonl" ]; then
    cp "$SCRIPT_DIR/claude-config/history.jsonl" "$HOME/.claude/history.jsonl"
    echo "✅ História bola skopírovaná."
fi

echo ""
echo "========================================"
echo "✅ Inštalácia dokončená!"
echo "========================================"
echo ""
echo "Dostupné príkazy:"
echo "  Docker: cd llm-gateway && docker compose logs"
echo "  Ukončiť: cd llm-gateway && docker compose down"
echo ""
echo "Dostupné free modely v Claude Code:"
echo "  /model claude-free-qwen3-coder"
echo "  /model claude-free-llama-3.3-70b"
echo "  /model claude-free-kimi-k2.6"
echo "  /model claude-free-gpt-oss-120b"
echo "  /model claude-free-glm-4.5-air"
echo "  /model claude-free-qwen3-next-80b"
echo ""
echo "Predvolený model: claude-free-kimi-k2.6"
echo ""
echo "Pre spustenie Claude Code a overenie: claude"
echo "========================================"
