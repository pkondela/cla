# Kompletná inštalácia a nastavenie Claude Code s free modelmi

## Obsah balíčka
Tento balíček obsahuje kompletné nastavenie Claude Code s free modelmi cez OpenRouter.

### Štruktúra balíčka:
```
claude-migration/
├── install.sh              - Skript pre inštaláciu
├── README.md               - Tento súbor
├── .env.template          - Template API kľúčov (doplňte svoje)
├── llm-gateway/           - Konfigurácia LLM gateway
│   ├── docker-compose.yml - Spustenie gatewayu
│   ├── litellm-config.yaml - Konfigurácia free modelov
│   ├── router/            - Router pre fallbacky
│   │   ├── Dockerfile
│   │   └── app.py
│   └── README.md          - Dokumentácia gatewayu
└── claude-config/         - Claude Code konfigurácia
    ├── settings.json      - Nastavenia Claude Code
    ├── history.jsonl      - História konverzácií
    └── projects/          - Projekty a dáta
        └── -home-home-claude/
            └── memory/    - Uložené dáta
```

## Inštalácia

### 1. Požiadavky
- Docker a Docker Compose
- Bash shell

### 2. Nastavenie API kľúčov
1. Otvorte `.env.template` v priečinku `llm-gateway/`
2. Doplňte svoje API kľúče:
   ```
   ANTHROPIC_API_KEY=sk-ant-api...
   OPENROUTER_API_KEY=sk-or-v1-...
   LITELLM_MASTER_KEY=sk-litellm-...
   GATEWAY_TOKEN=sk-gw-...
   ```
3. Prenajmenujte `.env.template` na `.env`

### 3. Spustenie inštalácie
```bash
./install.sh
```

Skript automaticky:
- Spustí LLM gateway
- Nakopíruje konfiguráciu do ~/.claude/
- Nastaví free modely v Claude Code

### 4. Overenie funkčnosti
1. Po spustení skontrolujte, či bežia kontajnery:
   ```bash
   docker ps | grep llm-gateway
   ```
2. V Claude Code by mali byť dostupné free modely:
   - claude-free-qwen3-coder
   - claude-free-llama-3.3-70b
   - claude-free-kimi-k2.6
   - claude-free-gpt-oss-120b
   - claude-free-glm-4.5-air
   - claude-free-qwen3-next-80b

### 5. Obnovenie histórie
Ak ste skopírovali `history.jsonl`, históriu konverzácií sa automaticky obnoví.

## Popis free modelov

### Zdarma dostupné modely cez OpenRouter:
1. **claude-free-qwen3-coder** - Qwen 3 Coder (1B parametrov)
2. **claude-free-llama-3.3-70b** - Llama 3.3 70B Instruct
3. **claude-free-kimi-k2.6** - Moonshot Kimi K2.6
4. **claude-free-gpt-oss-120b** - GPT-4o-mini-oss (120B parametrov)
5. **claude-free-glm-4.5-air** - Zhipu AI GLM-4.5-Air
6. **claude-free-qwen3-next-80b** - Qwen 3 Next 80B

### Fallback mechanizmus
Ak jeden model nie je dostupný (limit, timeout, error), automaticky sa skúša ďalší z fallback listu.

## Čistenie
Ak chcete gateway vypnúť:
```bash
cd llm-gateway
docker compose down
```

Ak chcete úplne odstrániť:
```bash
docker compose down -v
cd ..
rm -rf llm-gateway
```

## Troubleshooting

### Kontajnery nebežia
1. Skontrolujte Docker: `docker ps`
2. Skontrolujte logy: `cd llm-gateway && docker compose logs`
3. Overte API kľúče v `.env`

### Modely nie sú dostupné
1. Overte OpenRouter API kľúč
2. Skontrolujte limity na OpenRouter dashboard
3. Počkajte 5-10 minút po spustení gatewaya

### Claude Code nefunguje
1. Reštartujte Claude Code
2. Skontrolujte `~/.claude/settings.json`
3. Overte, či beží gateway na port 4000

## Bezpečnostné upozornenia
- Nikdy nezdieľajte svoje API kľúče
- Uložte `.env` súbor bezpečne
- Gateway beží len na localhost (127.0.0.1:4000)

## Aktualizácia
Na novom zariadení môžete nainštalovať novú verziu Claude Code a spustiť `./install.sh` znova.