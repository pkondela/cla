#!/bin/bash

# Auto Setup Script for Claude Migration
# Automatická inštalácia a konfigurácia Claude Code s free modelmi

echo "================================================"
echo "Claude Code Migration - Automatická Inštalácia"
echo "================================================"
echo ""

# Získanie cesty k skriptu
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# 1. Kontrola existujúceho balíka
if [ ! -f "claude-migration.zip" ]; then
    echo "❌ Nenašiel sa claude-migration.zip v aktuálnom priečinku"
    echo "Prosím, umiestnite tento skript do priečinka s migration balíčkom"
    exit 1
fi

# 2. Rozbalenie balíka
echo "📦 Rozbaľujem migration balíček..."
unzip -q claude-migration.zip
echo "✅ Balíček úspešne rozbalený"

# 3. Spustenie inštalácie
echo ""
echo "🚀 Spúšťam inštalačný skript..."
chmod +x claude-migration/install.sh
./claude-migration/install.sh

# 4. Ukončenie
echo ""
echo "================================================"
echo "✅ Hotovo! Všetko je pripravené."
echo ""
echo "Naďalej môžete:"
echo "- Spustiť: claude"
echo "- Skontrolovať: /model"
echo "- Zobraziť dostupné modely: /model"
echo ""
echo "Ak máte akékoľvek problémy, pozrite sa na README.md"
echo "================================================"
