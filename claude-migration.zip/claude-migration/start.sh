#!/bin/bash
set -e

# Kompletný auto-setup pre Claude Code + Free modely

echo "============================================"
echo "  Claude Code + Free modely - Auto Setup"
echo "============================================"
echo ""

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# 1. Overenie root/oprávnení
if [ "$EUID" -eq 0 ]; then
   echo "❌ Nech spúšťajte ako root (chardobné)"
   exit 1
fi

echo "✅ Používateľ: $USER"

# 2. Inštalácia potrebných balíčkov
echo ""
echo "📦 Kontrolujem závislosti..."

# Node.js + npm
if ! command -v node > /dev/null 2>&1; then
    echo "⚠️  Node.js nie je nainštalovaný. Inštalujem..."
    if command -v apt > /dev/null 2>&1; then
        curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
        sudo apt install -y nodejs
    elif command -v dnf > /dev/null 2>&1; then
        sudo dnf install -y nodejs npm
    elif command -v pacman > /dev/null 2>&1; then
        sudo pacman -S --noconfirm nodejs npm
    else
        echo "❌ Nepodarilo sa nainštalovať Node.js. Prosím nainštalujte manuálne."
        exit 1
    fi
fi

# Docker
if ! command -v docker > /dev/null 2>&1; then
    echo "⚠️  Docker nie je nainštalovaný. Inštalujem..."
    if command -v apt > /dev/null 2>&1; then
        curl -fsSL https://get.docker.com | sh
        sudo usermod -aG docker "$USER"
        echo "⚠️  Docker bol nainštalovaný. Prosím odhláste sa a znovu prihláste, alebo reštartujte."
        echo "   Potom spustite tento skript znova."
        exit 0
    else
        echo "❌ Nepodarilo sa nainštalovať Docker. Prosím nainštalujte manuálne."
        exit 1
    fi
fi

# Docker Compose
if ! command -v docker-compose > /dev/null 2>&1 && ! docker compose version > /dev/null 2>&1; then
    echo "⚠️  Docker Compose nie je nainštalovaný. Inštalujem..."
    if command -v apt > /dev/null 2>&1; then
        sudo apt install -y docker-compose-plugin
    fi
fi

# 3. Inštalácia Claude Code
echo ""
echo "🤖 Inštalujem Claude Code..."
if ! command -v claude > /dev/null 2>&1; then
    npm install -g @anthropic-ai/claude-code
    echo "✅ Claude Code nainštalovaný."
else
    echo "✅ Claude Code už je nainštalovaný."
fi

# 4. Povolenie priečinkov
echo ""
echo "🔧 Nastavujem práva priečinkov..."
mkdir -p "$HOME/.claude"
chmod -R u+rw "$HOME/.claude" 2> /dev/null || true

# 5. Rozbalenie balíka
echo ""
echo "📦 Rozbaľujem migration balíček..."
if [ -f "claude-migration.zip" ]; then
    unzip -q -o claude-migration.zip
    echo "✅ Balíček rozbalený."
else
    echo "❌ chýba claude-migration.zip v tomto priečinku!"
    exit 1
fi

# 6. API KĽÚČE - Interaktívny vstup
echo ""
echo "============================================"
echo "  Zadajte svoje API kľúče (Ctrl+C pre exit)"
echo "============================================"
echo ""

# Anthropic API Key
read -rp "🔑 Anthropic API Key (pre Claude pôvodný): " ANTHROPIC_KEY
while [ -z "$ANTHROPIC_KEY" ]; do
    echo "❌ Anthropic API Key je povinný!"
    read -rp "🔑 Anthropic API Key: " ANTHROPIC_KEY
done

# OpenRouter API Key
read -rp "🔑 OpenRouter API Key (pre free modely): " OPENROUTER_KEY
while [ -z "$OPENROUTER_KEY" ]; do
    echo "❌ OpenRouter API Key je povinný!"
    read -rp "🔑 OpenRouter API Key: " OPENROUTER_KEY
done

# LiteLLM Master Key (voliteľné, vygeneruje sa náhodné)
read -rp "🔧 LiteLLM Master Key (nechajte prázdne pre auto-generáciu): " LITELLM_KEY
if [ -z "$LITELLM_KEY" ]; then
    LITELLM_KEY="sk-litellm-$(openssl rand -hex 16 2> /dev/null || date +%s | sha256sum | head -c 32)"
    echo "   → Náhodný kľúč vygenerovaný."
fi

# Gateway Token (voliteľné)
read -rp "🔧 Gateway Token (nechajte prázdne pre auto-generáciu): " GW_TOKEN
if [ -z "$GW_TOKEN" ]; then
    GW_TOKEN="sk-gw-$(openssl rand -hex 16 2> /dev/null || date +%s | sha256sum | head -c 32)"
    echo "   → Náhodný token vygenerovaný."
fi

echo ""
echo "📝 Ukladám API kľúče..."
cat > claude-migration/llm-gateway/.env <<EOF
ANTHROPIC_API_KEY=${ANTHROPIC_KEY}
OPENROUTER_API_KEY=${OPENROUTER_KEY}
LITELLM_MASTER_KEY=${LITELLM_KEY}
GATEWAY_TOKEN=${GW_TOKEN}
EOF

echo "✅ API kľúče uložené."

# 7. Spustenie LLM Gateway
echo ""
echo "🚀 Spúšťam LLM Gateway..."
cd claude-migration/llm-gateway

if docker compose version > /dev/null 2>&1; then
    docker compose up -d --build
elif docker-compose version > /dev/null 2>&1; then
    docker-compose up -d --build
else
    echo "❌ Docker Compose nie je dostupný!"
    exit 1
fi

echo "⏳ Čakám na štart služieb (10 sekúnd)..."
sleep 10

# 8. Overenie gatewayu
echo ""
echo "🔍 Overujem LLM Gateway..."
if curl -s http://127.0.0.1:4000/health > /dev/null 2>&1 || docker ps | grep -q llm-gateway; then
    echo "✅ LLM Gateway beží úspešne."
else
    echo "⚠️  Gateway ešte nie je pripravený. Skontrolujte neskôr:"
    echo "   docker ps | grep llm-gateway"
fi

# 9. Kopírovanie konfigurácie do ~/.claude
echo ""
echo "📋 Kopírujem konfiguráciu Claude Code..."
cd "$SCRIPT_DIR"

mkdir -p "$HOME/.claude"
if [ -f "claude-migration/claude-config/settings.json" ]; then
    cp "claude-migration/claude-config/settings.json" "$HOME/.claude/settings.json"
    echo "✅ settings.json nastavený."
fi

if [ -d "claude-migration/claude-config/projects" ]; then
    mkdir -p "$HOME/.claude/projects"
    cp -r claude-migration/claude-config/projects/* "$HOME/.claude/projects/" 2> /dev/null || true
    echo "✅ Projektové dáta skopírované."
fi

if [ -f "claude-migration/claude-config/history.jsonl" ]; then
    if [ ! -f "$HOME/.claude/history.jsonl" ]; then
        cp "claude-migration/claude-config/history.jsonl" "$HOME/.claude/history.jsonl"
        echo "✅ História skopírovaná."
    else
        echo "ℹ️  História už existuje, preskakujem."
    fi
fi

# 10. Hotovo
echo ""
echo "============================================"
echo "  ✅ KOMPLETNÁ INŠTALÁCIA DOKONČENÁ!"
echo "============================================"
echo ""
echo "🤖 Claude Code je pripravený. Spustite: claude"
echo ""
echo "Dostupné free modely (príkaz v Claude):"
echo "  /model claude-free-qwen3-coder"
echo "  /model claude-free-llama-3.3-70b"
echo "  /model claude-free-kimi-k2.6 (predvolený)"
echo "  /model claude-free-gpt-oss-120b"
echo "  /model claude-free-glm-4.5-air"
echo "  /model claude-free-qwen3-next-80b"
echo ""
echo "📊 Kontrola gatewayu: docker ps | grep llm"
echo "🛑 Vypnutie: cd claude-migration/llm-gateway && docker compose down"
echo "📝 Logy: cd claude-migration/llm-gateway && docker compose logs -f"
echo ""
echo "🎮 Prajeme príjemnú prácu s Claude!"
echo "============================================"
