#!/bin/bash
set -e

# ============================================
#  Claude Code + Free/DeepSeek modely - Štart
#  Najprv skontroluje/nainštaluje Claude,
#  potom spustí interaktívnu inštaláciu.
# ============================================

echo "============================================"
echo "  Claude Code + Free/DeepSeek modely"
echo "============================================"
echo ""

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR"

# 1. Overenie root (nechceme)
if [ "$EUID" -eq 0 ]; then
   echo "❌ Nespúšťajte ako root!"
   exit 1
fi
echo "✅ Používateľ: $USER"

# 2. Rozbalenie claude-migration.zip (ak sa start.sh spúšťa z rozbaleného zipu)
echo ""
echo "📦 Kontrolujem migration balíček..."
if [ ! -d "claude-migration" ]; then
    if [ -f "claude-migration.zip" ]; then
        echo "   Rozbaľujem claude-migration.zip..."
        unzip -q -o claude-migration.zip
        echo "✅ Balíček rozbalený."
    else
        echo "❌ Nenašiel sa claude-migration.zip ani priečinok claude-migration/"
        echo "   Uistite sa, že ste v správnom priečinku."
        exit 1
    fi
else
    echo "✅ Priečinok claude-migration už existuje."
fi

# 3. Spustenie install.sh (ten už rieši Node.js, npm, Claude aj Docker)
echo ""
echo "🚀 Spúšťam kompletnú inštaláciu..."
chmod +x claude-migration/install.sh
cd claude-migration
./install.sh
cd "$SCRIPT_DIR"

echo ""
echo "============================================"
echo "  ✅ Všetko hotové!"
echo "============================================"
echo ""
echo "Spustite Claude Code:"
echo "  claude"
echo ""
echo "Prepnúť model v Claude:"
echo "  /model <názov-modelu>"
echo ""
echo "DeepSeek V4 (priamo na DeepSeek API):"
echo "  /model claude-deepseek-v4-flash"
echo "  /model claude-deepseek-v4-pro"
echo ""
echo "Free modely (cez OpenRouter):"
echo "  /model claude-free-nemotron-3-ultra    (najvýkonnejší free)"
echo "  /model claude-free-nemotron-3-super    (predvolený)"
echo "  /model claude-free-hermes-3-405b"
echo "  /model claude-free-qwen3-coder"
echo "  /model claude-free-kimi-k2.6"
echo "  /model claude-free-gemma-4-31b"
echo "  /model claude-free-llama-3.3-70b"
echo "  /model claude-free-glm-4.5-air"
echo "  /model claude-free-qwen3-next-80b"
echo "  /model claude-free-gpt-oss-120b"
echo ""
echo "============================================"
